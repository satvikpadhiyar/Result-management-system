<?php
$dbuser="root";
$dbpass="";
$host="";
$dbname = "";
$mysqli = new mysqli($host, $dbuser, $dbpass, $dbname);
?>